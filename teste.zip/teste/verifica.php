<?php
    session_start();
    $logado = $_SESSION['login'];
    $tipo = $_SESSION['tipo'];
    include 'conecta.php';
    $pesquisa = mysqli_query($conn, "SELECT * FROM usuario where login = '$logado' and tipo = 'admin'");
                    $row = mysqli_num_rows($pesquisa);
                    if($row > 0){
                        header('location:eadmin.php');
                    } else {
                        header('location:euser.php');
                    }
?>