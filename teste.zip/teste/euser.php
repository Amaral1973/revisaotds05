<?php
session_start();
$logado = $_SESSION['login'];
$tipo = $_SESSION['tipo'];
$nome = $_SESSION['nome'];
echo "Bem vindo $logado!!!<br/>";
echo "Você é um usuário!!!<br/>";
echo "Você foi cadastrado como: $tipo<br/>";
echo "Seu nome é: $nome<br/>";
?>