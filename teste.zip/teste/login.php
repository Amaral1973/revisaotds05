<?php
    session_start();
    include 'conecta.php';
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    $logar = mysqli_query($conn, "SELECT cliente.*,usuario.* FROM cliente,usuario where cliente.id = usuario.id_cliente and login='$login' AND senha='$senha'");
    if(mysqli_num_rows($logar)>0){
        while($registro = $logar->fetch_array()){
        $_SESSION['login'] = $registro['login'];
        $_SESSION['tipo'] = $registro['tipo'];
        $_SESSION['nome'] = $registro['nome'];
        }
        include 'verifica.php';
    }
    else {
        unset($_SESSION['login']);
        header('location:login.php');
    }
?>